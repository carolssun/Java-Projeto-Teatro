
package testeprojeto.projetoteatro;
import java.util.ArrayList;
import java.util.Scanner;

public class Teatro {
    private CadastroEspetaculo cadastroEspetaculo;
    private CadastroCliente cadastroCliente;
    private Scanner sc = new Scanner(System.in);

    // Construtor com CadastroEspetaculo
    public Teatro(CadastroEspetaculo cadastroEspetaculo) {
        this.cadastroEspetaculo = cadastroEspetaculo;
    }

    // Construtor com CadastroEspetaculo e CadastroCliente
    public Teatro(CadastroEspetaculo cadastroEspetaculo, CadastroCliente cadastroCliente) {
        this.cadastroEspetaculo = cadastroEspetaculo;
        this.cadastroCliente = cadastroCliente;
    }

    public void novaCompra() {
        System.out.println("\n***** Compra de Ingressos *****");

        // Verificar se há espetáculos cadastrados
        ArrayList<Espetaculo> espetaculos = cadastroEspetaculo.getEspetaculos();
        if (espetaculos.isEmpty()) {
            System.out.println("Nenhum espetáculo cadastrado. Cadastre um espetáculo antes de continuar.");
            return;
        }

        // Listar os espetáculos cadastrados
        apresentaEspetaculos(espetaculos);

        // Selecionar o espetáculo
        Espetaculo espetaculoSelecionado = selecionaEspetaculo(espetaculos);
        if (espetaculoSelecionado == null) return;

        // Iniciar o pedido
        Pedido pedido = novaEntrada(espetaculoSelecionado);

        // Perguntar se deseja finalizar a compra
        System.out.println("\nDeseja finalizar a compra?");
        System.out.print("Digite 's' para sim ou 'n' para cancelar: ");
        String respostaFinalizar = sc.nextLine().trim().toLowerCase();

        /*if ("n".equals(respostaFinalizar)) {
            // Cancelar compra e liberar assentos se o usuario não finalizar compra
            for (Entrada entrada : pedido.getEntradas()) {
                espetaculoSelecionado.liberarAssento(entrada.getNumeroAssento());
            }
            System.out.println("Compra cancelada. Assentos liberados.");
            return;
        }*/
        if ("n".equals(respostaFinalizar)) {
            System.out.println("Liberando assentos para a compra cancelada...");
    // Cancelar compra e liberar assentos
    for (Entrada entrada : pedido.getEntradas()) {
        espetaculoSelecionado.liberarAssento(entrada.getNumeroAssento());
        
        System.out.println("Liberando o assento número: " + entrada.getNumeroAssento()); // Mensagem de depuração
        espetaculoSelecionado.liberarAssento(entrada.getNumeroAssento());
    }
    System.out.println("Compra cancelada. Assentos liberados.");
    return;
}

        if ("n".equals(respostaFinalizar)) {
    // Adicione esta mensagem para indicar o início do processo de liberação de assentos
    System.out.println("Liberando assentos para a compra cancelada...");
    
    // Loop para liberar os assentos associados ao pedido
    for (Entrada entrada : pedido.getEntradas()) {
        System.out.println("Liberando o assento número: " + entrada.getNumeroAssento()); // Mensagem de depuração
        espetaculoSelecionado.liberarAssento(entrada.getNumeroAssento());
    }
    
    System.out.println("Compra cancelada. Assentos liberados."); // Mensagem final
    return;
}



        // Solicitar CPF do cliente para associar com a compra
        System.out.print("Informe o CPF do cliente: ");
        String cpfCliente = sc.nextLine().trim();

        // Verificar se o cliente está cadastrado
        Cliente cliente = cadastroCliente.buscarClientePorCPF(cpfCliente);
        if (cliente == null) {
    System.out.println("CPF não identificado. Por favor, cadastre o cliente primeiro.");
    
    // Liberar os assentos reservados
    for (Entrada entrada : pedido.getEntradas()) {
        espetaculoSelecionado.liberarAssento(entrada.getNumeroAssento());
    }
    
    System.out.println("Compra cancelada. Assentos liberados.");
    return;
}

        // Associar o pedido ao cliente
        cliente.adicionaPedido(pedido);

        // Exibir valor total da compra
        System.out.println("\nCompra finalizada com sucesso!");
        System.out.println("Valor total: R$ " + pedido.calculaValorTotal());
    }

    public void apresentaEspetaculos(ArrayList<Espetaculo> espetaculos) {
        System.out.println("Espetáculos disponíveis:");
        for (int i = 0; i < espetaculos.size(); i++) {
            System.out.println((i + 1) + " - " + espetaculos.get(i).toString());
        }
    }

    public Espetaculo selecionaEspetaculo(ArrayList<Espetaculo> espetaculos) {
        System.out.print("Selecione o número do espetáculo desejado: ");
        int escolhaEspetaculo = sc.nextInt();
        sc.nextLine();

        if (escolhaEspetaculo < 1 || escolhaEspetaculo > espetaculos.size()) {
            System.out.println("Opção inválida.");
            return null;
        }

        return espetaculos.get(escolhaEspetaculo - 1);
    }

    public Pedido novaEntrada(Espetaculo espetaculoSelecionado) {
        boolean novaEntrada = true;
        Pedido pedido = new Pedido();

        while (novaEntrada) {
            // Mostrar os assentos disponíveis
            System.out.println("\nAssentos disponíveis (XX = ocupado):");
            espetaculoSelecionado.apresentaAssentos();

            System.out.print("Escolha o número do assento: ");
            int numeroAssento = sc.nextInt();
            sc.nextLine(); 

            if (numeroAssento < 1 || numeroAssento > 50) {
                System.out.println("Número de assento inválido.");
                continue;
            }

            if (!espetaculoSelecionado.verificaDisponibilidadeAssento(numeroAssento)) {
                System.out.println("Assento já ocupado. Escolha outro.");
                continue;
            }

            // Escolher o tipo de entrada
            System.out.println("\nTipos de Entrada:");
            System.out.println("1 - Inteira");
            System.out.println("2 - Meia  50% do valor da entrada");
            System.out.println("3 - Professor  60% do valor da entrada");
            System.out.print("Escolha o tipo de entrada: ");
            int tipoEntrada = sc.nextInt();
            sc.nextLine();

            Entrada entrada;
            switch (tipoEntrada) {
                case 1:
                    entrada = new EntradaInteira(numeroAssento, espetaculoSelecionado.getPreco());
                    break;
                case 2:
                    entrada = new EntradaMeia(numeroAssento, espetaculoSelecionado.getPreco());
                    break;
                case 3:
                    entrada = new EntradaProfessor(numeroAssento, espetaculoSelecionado.getPreco());
                    break;
                default:
                    System.out.println("Tipo de entrada inválido. Tente novamente.");
                    continue;
            }

            pedido.adicionaEntrada(entrada);

            // Marcar o assento temporariamente
            espetaculoSelecionado.marcarAssento(numeroAssento);

            // Perguntar se deseja adicionar nova entrada
            System.out.print("Deseja comprar uma nova entrada? (s/n): ");
            String resposta = sc.nextLine().trim().toLowerCase();
            novaEntrada = resposta.equals("s");
        }

        return pedido;
    }
}
