package testeprojeto.projetoteatro;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class CadastroEspetaculo {
    private ArrayList<Espetaculo> espetaculos;
    private Espetaculo[] lista = new Espetaculo[1000];
    private int qtdClientes = 0; 
    private Scanner sc = new Scanner(System.in);

    public CadastroEspetaculo() {
        espetaculos = new ArrayList<>();
        adicionarEspetaculosPreDefinidos();
    }

    // Método para adicionar espetáculos pré-definidos
    private void adicionarEspetaculosPreDefinidos() {
        Espetaculo espetaculo1 = new Espetaculo("Rei Leão", "10/11/2024", "19:00", 50.0);
        espetaculo1.marcarAssento(3);
        espetaculo1.marcarAssento(25);
        espetaculo1.marcarAssento(31);
        espetaculo1.marcarAssento(32);
        espetaculo1.marcarAssento(33);
        espetaculo1.marcarAssento(34);
        espetaculo1.marcarAssento(40);
        espetaculos.add(espetaculo1);

        Espetaculo espetaculo2 = new Espetaculo("Wicked", "29/11/2024", "18:00", 50.0);
        espetaculo2.marcarAssento(23);
        espetaculo2.marcarAssento(24);
        espetaculo2.marcarAssento(25);
        espetaculo2.marcarAssento(26);
        espetaculo2.marcarAssento(38);
        espetaculo2.marcarAssento(39);
        espetaculo2.marcarAssento(40);
        espetaculo2.marcarAssento(14);
        espetaculo2.marcarAssento(13);
        espetaculo2.marcarAssento(16);
        espetaculo2.marcarAssento(45);
        espetaculos.add(espetaculo2);

        Espetaculo espetaculo3 = new Espetaculo("Alladin", "22/11/2024", "13:45", 30.0);
        espetaculo3.marcarAssento(1);
        espetaculo3.marcarAssento(2);
        espetaculo3.marcarAssento(3);
        espetaculo3.marcarAssento(8);
        espetaculo3.marcarAssento(9);
        espetaculo3.marcarAssento(10);
        espetaculo3.marcarAssento(21);
        espetaculo3.marcarAssento(29);
        espetaculo3.marcarAssento(28);
        espetaculo3.marcarAssento(27);
        espetaculo3.marcarAssento(30);
        espetaculo3.marcarAssento(37);
        espetaculo3.marcarAssento(41);
        espetaculo3.marcarAssento(42);
        espetaculos.add(espetaculo3);
    }

    // Método para cadastrar um novo espetáculo com validação de data e horário
  
  public void cadastrarEspetaculo() {
    Scanner sc = new Scanner(System.in);
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    
    Espetaculo espetaculo = new Espetaculo("", null, null, 0.0);
    
    System.out.print("Informe o nome do espetáculo: ");
    String nome = sc.nextLine();

    String data;
    while (true) {
        System.out.print("Informe a data do espetáculo (dd/mm/aaaa): ");
        data = sc.nextLine();
        try {
            LocalDate.parse(data, dateFormatter); 
            break; 
        } catch (DateTimeParseException e) {
            System.out.println("Data inválida. Por favor, tente novamente.");
        }
    }

    String hora;
    while (true) {
        System.out.print("Informe o horário do espetáculo (hh:mm): ");
        hora = sc.nextLine();
        try {
            LocalTime.parse(hora, timeFormatter); 
            break; 
        } catch (DateTimeParseException e) {
            System.out.println("Horário inválido. Por favor, tente novamente.");
        }
    }  
    
    System.out.print("Digite o valor da entrada inteira: R$ ");
    double preco = sc.nextDouble();

    // Configura os atributos do espetáculo
    espetaculo.setNome(nome);
    espetaculo.setData(data);
    espetaculo.setHora(hora);
    espetaculo.setValorEntrada(preco);

    // Adiciona o espetáculo à lista de espetáculos
    espetaculos.add(espetaculo);

    System.out.println("\nEspetáculo cadastrado com sucesso!");
    System.out.println(espetaculo); // Mostra os detalhes do espetáculo
}


    public ArrayList<Espetaculo> getEspetaculos() {
        return espetaculos;
    }
}