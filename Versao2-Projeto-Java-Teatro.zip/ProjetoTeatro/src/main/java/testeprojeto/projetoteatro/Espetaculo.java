
package testeprojeto.projetoteatro;

import java.time.LocalDate;
import java.time.LocalTime;

public class Espetaculo {
    private String nome;
    private String data;
    private String horario;
    private double preco;
    private boolean[] assentos = new boolean[50];  // Supondo que haja 50 assentos

    public Espetaculo(String nome, String data, String horario, double preco) {
        this.nome = nome;
        this.data = data;
        this.horario = horario;
        this.preco = preco;
        
        // Inicializa todos os assentos como disponíveis
        for (int i = 0; i < assentos.length; i++) {
            assentos[i] = true;  // Disponível
        }
    }

     // Métodos Get e Set
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return horario;
    }

    public void setHora(String hora) {
        this.horario = horario;
    }

    public double getPreco() {
        return preco;
    }

    public void setValorEntrada(double preco) {
        this.preco = preco;
    }

    
  
    public boolean[] getAssentos() {
        return assentos;
    }

    public void apresentaAssentos() {
    for (int i = 0; i < assentos.length; i++) {
        if (assentos[i]) {
            System.out.print((i + 1) + " "); // Assento disponível
        } else {
            System.out.print("xx "); // Assento ocupado
        }

        // Adiciona um espaço para formatação
        if ((i + 1) % 10 == 0) {
            System.out.println(); // Nova linha a cada 10 assentos
        }
    }
    System.out.println(); // Quebra de linha ao final da lista de assentos
}


    public boolean verificaDisponibilidadeAssento(int numeroAssento) {
        return assentos[numeroAssento - 1];
    }

    public void marcarAssento(int numeroAssento) {
        assentos[numeroAssento - 1] = false;
    }
    
    /*public void liberarAssento(int numeroAssento) {
    if (numeroAssento > 0 && numeroAssento <= 50) {
        assentos[numeroAssento - 1] = false;
    }
}*/
    public void liberarAssento(int numeroAssento) {
    // Verifique se o número do assento está dentro do intervalo válido
    if (numeroAssento < 1 || numeroAssento > assentos.length) {
        System.out.println("Número de assento inválido ao liberar: " + numeroAssento);
        return;
    }

    // Atualize o status do assento para disponível
    assentos[numeroAssento - 1] = true; // Supondo que `true` significa "disponível"
    System.out.println("Assento " + numeroAssento + " liberado com sucesso."); // Mensagem de depuração
}






    @Override
    public String toString() {
        return nome + " - " + data + " " + horario + "- Valor Entrada: " + preco;
    }
}

  
 