package testeprojeto.projetoteatro;

import java.util.List;
import java.util.ArrayList;

public class Cliente {
    private String nome;
    private String CPF;
    private List<Pedido> pedidos = new ArrayList<>();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }
    
    public void adicionaPedido(Pedido pedido) {
        pedidos.add(pedido);
        System.out.println("Pedido adicionado com sucesso!");
    }
}
