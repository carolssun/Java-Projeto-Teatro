
package continuacaoprojeto;
import java.util.ArrayList;

public class Pedido {
    private ArrayList<Entrada> entradas = new ArrayList<>();

    public void adicionaEntrada(Entrada entrada) {
        if (entrada != null) {
            entradas.add(entrada);
        }
    }

    public double calculaValorTotal() {
        double total = 0.0;
        for (Entrada entrada : entradas) {
            total += entrada.calculaValor();
        }
        return total;
    }
}
