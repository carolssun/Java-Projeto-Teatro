
package continuacaoprojeto;
import java.util.ArrayList;
import java.util.List;

public class Teatro {
    private Espetaculo espetaculoSelecionado = null;
    private List<Entrada> entradas = new ArrayList<>();

    public Teatro() {
        // Inicializa a lista de entradas e outros atributos, se necessário
    }

    // Método para listar os espetáculos disponíveis
    public void apresentaEspetaculos() {
        // Exibe os espetáculos cadastrados
        System.out.println("1 - Show de Comédia");
        System.out.println("2 - Peça de Teatro");
    }

    // Método para selecionar um espetáculo
    public void selecionaEspetaculo(int numero) {
        // Atribui o espetáculo selecionado à variável espetaculoSelecionado
        if (numero == 1) {
            espetaculoSelecionado = new Espetaculo("Show de Comédia", "2024-12-01", "20:00", 100.0);
        } else if (numero == 2) {
            espetaculoSelecionado = new Espetaculo("Peça de Teatro", "2024-12-02", "18:00", 120.0);
        } else {
            System.out.println("Espetáculo inválido!");
        }
    }

    // Método para apresentar os assentos disponíveis
    public void apresentaAssentos() {
        if (espetaculoSelecionado != null) {
            boolean[] assentos = espetaculoSelecionado.getAssentos();
            for (int i = 0; i < assentos.length; i++) {
                if (assentos[i]) {
                    System.out.println("Assento " + (i + 1) + " disponível");
                } else {
                    System.out.println("Assento " + (i + 1) + " ocupado");
                }
            }
        } else {
            System.out.println("Nenhum espetáculo selecionado.");
        }
    }

    // Método para marcar o assento como ocupado
    public void marcarAssento(int assento) {
        if (espetaculoSelecionado != null && assento >= 1 && assento <= espetaculoSelecionado.getAssentos().length) {
            if (espetaculoSelecionado.getAssentos()[assento - 1]) {
                espetaculoSelecionado.getAssentos()[assento - 1] = false;
                System.out.println("Assento " + assento + " reservado com sucesso!");
            } else {
                System.out.println("Esse assento já está ocupado!");
            }
        } else {
            System.out.println("Número de assento inválido.");
        }
    }

    // Método para realizar a compra de ingressos
    public void novaCompra(int tipoEntrada, int numeroAssento) {
        if (espetaculoSelecionado != null) {
            if (espetaculoSelecionado.verificaDisponibilidadeAssento(numeroAssento)) {
                espetaculoSelecionado.marcarAssento(numeroAssento);

                Entrada entrada;
                switch (tipoEntrada) {
                    case 1:
                        entrada = new EntradaInteira(numeroAssento, espetaculoSelecionado.getPreco());
                        break;
                    case 2:
                        entrada = new EntradaMeia(numeroAssento, espetaculoSelecionado.getPreco());
                        break;
                    case 3:
                        entrada = new EntradaProfessor(numeroAssento, espetaculoSelecionado.getPreco());
                        break;
                    default:
                        System.out.println("Tipo de entrada inválido!");
                        return;
                }
                entradas.add(entrada);
                System.out.println("Entrada adicionada com sucesso!");
            } else {
                System.out.println("Assento já ocupado.");
            }
        } else {
            System.out.println("Nenhum espetáculo selecionado.");
        }
    }

    public List<Entrada> getEntradas() {
        return entradas;
    }

    public Espetaculo getEspetaculoSelecionado() {
        return espetaculoSelecionado;
    }

    public void finalizarCompra(String cpf) {
        double valorTotal = 0;
        for (Entrada entrada : entradas) {
            valorTotal += entrada.calculaValor();
        }
        System.out.println("CPF do cliente: " + cpf);
        System.out.println("Valor total a pagar: R$ " + valorTotal);
    }
}
