
package continuacaoprojeto;
import java.util.Scanner;
import java.util.ArrayList;

public class Execucao {
    private static Scanner sc = new Scanner(System.in);
    private static CadastroEspetaculo cadastroEspetaculo = new CadastroEspetaculo();
    private static CadastroCliente cadastroCliente = new CadastroCliente();

    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("\n***** Menu Principal *****\n");
            System.out.println("1 - Cadastrar Espetáculo");
            System.out.println("2 - Cadastrar Cliente");
            System.out.println("3 - Compra de Ingressos");
            System.out.println("4 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt();
            sc.nextLine(); // Limpar buffer

            switch (opcao) {
                case 1:
                    System.out.println("\n***** Cadastro de Espetáculo *****");
                    cadastroEspetaculo.cadastrarEspetaculo();
                    break;

                case 2:
                    System.out.println("\n***** Cadastro de Cliente *****");
                    cadastroCliente.cadastrarCliente();
                    break;

                case 3:
                    System.out.println("\n***** Compra de Ingressos *****");
                    realizarCompra();
                    break;

                case 4:
                    System.out.println("Saindo do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 4);

        sc.close();
    }

    private static void realizarCompra() {
        System.out.println("\n***** Compra de Ingressos *****");

        ArrayList<Espetaculo> espetaculos = cadastroEspetaculo.getEspetaculos();

        if (espetaculos.isEmpty()) {
            System.out.println("Nenhum espetáculo cadastrado. Cadastre um espetáculo antes de continuar.");
            return;
        }

        // Listar espetáculos cadastrados
        System.out.println("Espetáculos disponíveis:");
        for (int i = 0; i < espetaculos.size(); i++) {
            System.out.println((i + 1) + " - " + espetaculos.get(i).toString());
        }

        System.out.print("Selecione o número do espetáculo desejado: ");
        int escolhaEspetaculo = sc.nextInt();
        sc.nextLine(); // Limpar buffer

        if (escolhaEspetaculo < 1 || escolhaEspetaculo > espetaculos.size()) {
            System.out.println("Opção inválida.");
            return;
        }

        Espetaculo espetaculoSelecionado = espetaculos.get(escolhaEspetaculo - 1);

        boolean novaEntrada = true;
        Pedido pedido = new Pedido();

        while (novaEntrada) {
            // Mostrar os assentos disponíveis
            System.out.println("\nAssentos disponíveis (XX = ocupado):");
            espetaculoSelecionado.apresentaAssentos();

            System.out.print("Escolha o número do assento: ");
            int numeroAssento = sc.nextInt();
            sc.nextLine(); // Limpar buffer

            if (numeroAssento < 1 || numeroAssento > 50) {
                System.out.println("Número de assento inválido.");
                continue;
            }

            if (!espetaculoSelecionado.verificaDisponibilidadeAssento(numeroAssento)) {
                System.out.println("Assento já ocupado. Escolha outro.");
                continue;
            }

            // Escolher o tipo de entrada
            System.out.println("\nTipos de Entrada:");
            System.out.println("1 - Inteira");
            System.out.println("2 - Meia  50% do valor da entrada");
            System.out.println("3 - Professor  60% do valor da entrada");
            System.out.print("Escolha o tipo de entrada: ");
            int tipoEntrada = sc.nextInt();
            sc.nextLine(); // Limpar buffer

            Entrada entrada;
            switch (tipoEntrada) {
                case 1:
                    entrada = new EntradaInteira(numeroAssento, espetaculoSelecionado.getPreco());
                    break;
                case 2:
                    entrada = new EntradaMeia(numeroAssento, espetaculoSelecionado.getPreco());
                    break;
                case 3:
                    entrada = new EntradaProfessor(numeroAssento, espetaculoSelecionado.getPreco());
                    break;
                default:
                    System.out.println("Tipo de entrada inválido. Tente novamente.");
                    continue;
            }

            pedido.adicionaEntrada(entrada);
            espetaculoSelecionado.marcarAssento(numeroAssento);

            // Perguntar se deseja adicionar nova entrada
            System.out.print("Deseja comprar uma nova entrada? (s/n): ");
            String resposta = sc.nextLine().trim().toLowerCase();
            novaEntrada = resposta.equals("s");
        }

        // Finalizar compra
        System.out.print("Informe o CPF do cliente: ");
        String cpfCliente = sc.nextLine();

        Cliente cliente = cadastroCliente.buscarClientePorCPF(cpfCliente);
        if (cliente == null) {
            System.out.println("Cliente não encontrado. Cadastre o cliente primeiro.");
            return;
        }

        cliente.adicionaPedido(pedido);

        System.out.println("\nCompra finalizada com sucesso!");
        System.out.println("Valor total: R$ " + pedido.calculaValorTotal());
    }
}
