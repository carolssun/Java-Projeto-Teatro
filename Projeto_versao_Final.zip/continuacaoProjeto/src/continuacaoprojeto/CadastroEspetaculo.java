package continuacaoprojeto;
import java.util.ArrayList;
import java.util.Scanner;

public class CadastroEspetaculo {
    private ArrayList<Espetaculo> espetaculos;

    public CadastroEspetaculo() {
        espetaculos = new ArrayList<>();
        // Chamando o método para adicionar os espetáculos pré-definidos
        adicionarEspetaculosPreDefinidos();
    }

    // Método para adicionar espetáculos pré-definidos
    private void adicionarEspetaculosPreDefinidos() {
        // Espetáculo 1: Rei Leão
        Espetaculo espetaculo1 = new Espetaculo("Rei Leão", "10/11/2024", "19:00", 50.0);
        espetaculo1.marcarAssento(3);
        espetaculo1.marcarAssento(25);
        espetaculo1.marcarAssento(31);
        espetaculo1.marcarAssento(32);
        espetaculo1.marcarAssento(33);
        espetaculo1.marcarAssento(34);
        espetaculo1.marcarAssento(40);
        espetaculos.add(espetaculo1);

        
        Espetaculo espetaculo2 = new Espetaculo("Wicked", "29/11/2024", "18:00", 50.0);
        espetaculo2.marcarAssento(23);
        espetaculo2.marcarAssento(24);
        espetaculo2.marcarAssento(25);
        espetaculo2.marcarAssento(26);
        espetaculo2.marcarAssento(38);
        espetaculo2.marcarAssento(39);
        espetaculo2.marcarAssento(40);
        espetaculo2.marcarAssento(14);
        espetaculo2.marcarAssento(13);
        espetaculo2.marcarAssento(16);
        espetaculo2.marcarAssento(45);
        espetaculos.add(espetaculo2);

        
        Espetaculo espetaculo3 = new Espetaculo("Espetáculo", "22/11/2024", "13:45", 30.0);
        espetaculo3.marcarAssento(1);
        espetaculo3.marcarAssento(2);
        espetaculo3.marcarAssento(3);
        espetaculo3.marcarAssento(8);
        espetaculo3.marcarAssento(9);
        espetaculo3.marcarAssento(10);
        espetaculo3.marcarAssento(21);
        espetaculo3.marcarAssento(29);
        espetaculo3.marcarAssento(28);
        espetaculo3.marcarAssento(27);
        espetaculo3.marcarAssento(30);
        espetaculo3.marcarAssento(37);
        espetaculo3.marcarAssento(41);
        espetaculo3.marcarAssento(42);
        espetaculos.add(espetaculo3);
    }

   
    public void cadastrarEspetaculo() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Informe o nome do espetáculo: ");
        String nome = sc.nextLine();

        System.out.print("Informe a data do espetáculo (dd/mm/aaaa): ");
        String data = sc.nextLine();

        System.out.print("Informe o horário do espetáculo (hh:mm): ");
        String hora = sc.nextLine();

        System.out.print("Informe o preço da entrada: ");
        double preco = sc.nextDouble();

        Espetaculo espetaculo = new Espetaculo(nome, data, hora, preco);
        espetaculos.add(espetaculo);

        System.out.println("Espetáculo cadastrado com sucesso!");
    }

    
    public ArrayList<Espetaculo> getEspetaculos() {
        return espetaculos;
    }
}
