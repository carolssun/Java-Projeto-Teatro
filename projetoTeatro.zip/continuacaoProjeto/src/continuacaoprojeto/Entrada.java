
package continuacaoprojeto;
public class Entrada {
    protected int numeroAssento;
    protected double preco;

    public Entrada(int numeroAssento, double preco) {
        this.numeroAssento = numeroAssento;
        this.preco = preco;
    }

    public double calculaValor() {
        return preco;
    }

    @Override
    public String toString() {
        return "Assento: " + numeroAssento + " | Valor: R$ " + calculaValor();
    }
}

class EntradaInteira extends Entrada {
    public EntradaInteira(int numeroAssento, double preco) {
        super(numeroAssento, preco);
    }

    @Override
    public double calculaValor() {
        return preco; // Valor inteiro
    }
}

class EntradaMeia extends Entrada {
    public EntradaMeia(int numeroAssento, double preco) {
        super(numeroAssento, preco);
    }

    @Override
    public double calculaValor() {
        return preco / 2; // Meia entrada
    }
}

class EntradaProfessor extends Entrada {
    public EntradaProfessor(int numeroAssento, double preco) {
        super(numeroAssento, preco);
    }

    @Override
    public double calculaValor() {
        return preco * 0.6; // Desconto para professores (60% do valor original)
    }
}
